//
//  AppDelegate.h
//  ball
//
//  Created by Ahmed Hussien on 29/10/1443 AH.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

