//
//  SceneDelegate.h
//  table_pods
//
//  Created by Ahmed Hussien on 29/10/1443 AH.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

