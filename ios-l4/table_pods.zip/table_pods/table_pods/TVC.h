//
//  TVC.h
//  table_pods
//
//  Created by Ahmed Hussien on 29/10/1443 AH.
//

#import <UIKit/UIKit.h>
#import <SDWebImage/SDWebImage.h>
NS_ASSUME_NONNULL_BEGIN

@interface TVC : UITableViewController
@property NSMutableArray *imags;

@end

NS_ASSUME_NONNULL_END
